

<html>
  <head>
    <meta charset="utf-8">
    <title>Lagu Anak</title>
    <link rel="stylesheet" href= "/asset/css/custom.css" media="screen" title="no title" charset="utf-8">
  </head>
  <body>
    <h1 id="judul">Koleksi Lagu Anak</h1>
    <hr>

    <h1 id="jl">Balonku</h1>
    <img id="gambar" src="/asset/img/balon.jpg">

    <p id="lagu">
      Balonku ada lima <br>
      Rupa-rupa warnanya <br>
      Hijau, kuning, kelabu <br>
      Merah muda dan biru <br>
      Meletus balon hijau DOR! <br>
      Hatiku sangat kacau <br>
      Balonku tinggal empat <br>
      Kupegang erat-erat <br>
    </p>
    <a href="<?php echo site_url('welcome/home') ?>">Home</a>

  </body>
</html>
