<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Lagu Anak</title>
    <link rel="stylesheet" href="/asset/css/custom.css" media="screen" title="no title" charset="utf-8">
  </head>
  <body>
    <h1 id="judul">Koleksi Lagu Anak</h1>
    <hr>

    <h1 id="jl">Cicak</h1>
    <img id="gambar" src="/asset/img/cicak.jpg">

    <p id="lagu">
      Cicak-cicak di dinding <br>
      Diam diam merayap <br>
      Datang seekor nyamuk <br>
      Hap ... lalu ditangkap <br>
    </p>

    <a href="<?php echo site_url('welcome/home') ?>">Home</a>

  </body>
</html>
