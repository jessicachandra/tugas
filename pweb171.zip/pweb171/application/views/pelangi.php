

<html>
  <head>
    <meta charset="utf-8">
    <title>Lagu Anak</title>
    <link rel="stylesheet" href="/asset/css/custom.css" media="screen" title="no title" charset="utf-8">
  </head>
  <body>
    <h1 id="judul">Koleksi Lagu Anak</h1>
    <hr>

    <h1 id="jl">Pelangi</h1>
    <img id="gambar" src="/asset/img/Pelangi.jpg">

    <p id="lagu">
      Pelangi-pelangi<br>
      Alangkah indahmu<br>
      Merah-kuning-hijau<br>
      Di langit yang biru<br>
      Pelukismu Agung<br>
      Siapa gerangan<br>
      Pelangi-pelangi<br>
      Ciptaan Tuhan<br>
    </p>
<a href="<?php echo site_url('welcome/home') ?>">Home</a>

  </body>
</html>
