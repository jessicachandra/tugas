<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Lagu Anak</title>
    <link rel="stylesheet" href="/asset/css/custom.css" media="screen" title="no title" charset="utf-8">
  </head>
  <body>
    <h1 id="judul">Koleksi Lagu Anak</h1>
    <hr>

    <h1 id="jl">Kereta</h1>
    <img id="gambar" src="/asset/kereta.jpg">

    <p id="lagu">
      Naik kereta api … tut … tut … tut <br>
      Siapa hendak turut <br>
      Ke Bandung … Surabaya <br>
      Bolehlah naik dengan percuma <br>
      Ayo temanku lekas naik <br>
      Keretaku tak berhenti lama <br>
    </p>

    <a href="<?php echo site_url('welcome/home') ?>">Home</a>

  </body>
</html>
