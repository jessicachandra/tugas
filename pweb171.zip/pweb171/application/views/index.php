

<html>
  <head>
    <meta charset="utf-8">
    <title>Lagu Anak</title>
      <link rel="stylesheet" href="/asset/css/custom.css" media="screen" title="no title" charset="utf-8">
      <link href="https://fonts.googleapis.com/css?family=Abril+Fatface" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Bree+Serif" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Berkshire+Swash" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Arvo" rel="stylesheet">
  </head>
  <body>
    <h1 id="judul">Koleksi lagu anak</h1>
    <hr>
<div class="">

    <div id="menu">

      <a href="<?php echo site_url('welcome/menu1') ?>">Pelangi</a><br>
      <a href="<?php echo site_url('welcome/menu2') ?>">Balon Ku</a><br>
      <a href="<?php echo site_url('welcome/menu3') ?>">Kereta</a><br>
      <a href="<?php echo site_url('welcome/menu4') ?>">Cicak</a><br>
      <a href="<?php echo site_url('welcome/menu5') ?>">Kebun Ku</a><br>

    </div>

<div id="isi">

  <img src="/asset/img/anak2.png"

</div>
</div>
    <br>
    <br>
    didesain oleh: Jessica Chandra; 2018





  </body>
</html>
